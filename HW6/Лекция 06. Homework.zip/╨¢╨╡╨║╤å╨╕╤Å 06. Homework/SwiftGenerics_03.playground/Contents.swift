import UIKit

// MARK: - Задача 3*. К выполнению необязательна.

enum LinkedList<T> {
    indirect case value(element: T, next: LinkedList<T>)
    case end
}

let element1 = LinkedList.value(element: "1", next: element2)
let element2 = LinkedList.value(element: "2", next: element3)
let element3 = LinkedList.value(element: "3", next: .end)

print(element2)
