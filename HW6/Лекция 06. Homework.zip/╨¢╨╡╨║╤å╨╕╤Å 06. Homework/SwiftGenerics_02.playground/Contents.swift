import UIKit

// MARK: - Задача 2

protocol Container {
    
    associatedtype Item
    
    func count() -> Int
    mutating func add(element: Item)
    func returnElement(index: Int) -> Item
}

class Сomponent<T> {
    var value: T? = nil
    var next: Сomponent? = nil
    var index = 0
}

//Связный список

struct LinkedList<T>: Container {
    
    var component = Сomponent<T>()
    var countList = 0
    
    func count() -> Int {
        return countList
    }
    
    mutating func add(element: T) {
        if component.value == nil {
            self.component.value = element
            countList = 1
        } else {
            var lastElement = self.component
            while lastElement.next != nil {
                if let nextElement = lastElement.next{
                    lastElement = nextElement
                }
            }
            let nextElement = Сomponent<T>()
            nextElement.value = element
            nextElement.index = lastElement.index + 1
            lastElement.next = nextElement
            countList += 1
        }
    }
    
    func returnElement(index: Int) -> T {
        var element: Сomponent! = component
        while element.value != nil && element.index != index {
            element = element.next
        }
        return element.value!
    }
}

// Универсальная очередь (FIFO)

struct Queue<T>: Container {
    var queue = [T]()
    
    mutating func add(element: T) {
        queue.append(element)
    }
    func count() -> Int {
        return queue.count
    }
    
    func returnElement(index: Int) -> T {
        return queue[index]
    }
}
